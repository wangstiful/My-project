export default {
  // page1部分
  page1: {
    titleEn: 'Hello,I`m Wangs Ti Ful', //英文标题
    title: '一个学习Web前端的小白-王添锋', //中文标题
  },
  // page2部分
  page2: {
    authorImg: 'page1.jpg', // 作者头像
    xinhui: '我叫王添锋，是一名在读的大一学生。', // 幸会
    qiuzhi: '学校：广东东软学院', // 求职意向
    qiuzhi1: '专业:信息安全技术应用', 
    qiuzhi2: '学号：21213110119', 
    guanyuwo: '掌握了前端js、html、css基本技术和Vue框架、UI框架，nodejs等等，同时也研究学习了一些的Python爬虫，有独立开发过多个脚本的经验！' // 关于我
  },
  // page3部分
  page3: [{
    icon: 'icon-tubiao-',
    title: 'UI设计',
    msg: ['PS切图、界面排版']
  },{
    icon: 'icon-diannao', // 图标
    title: '网页制作', // 标题
    msg: ['响应式页面', 'css、scss动画效果',] //介绍
  }, {
    icon: 'icon-qianbi1',
    title: '前端功能',
    msg: ['JS完成常见的交互功能', '用AJAX读取后台数据且渲染']
  },  {
    icon: 'icon-shouji',
    title: '框架',
    msg: ['vue框架','UI框架、express框架、mysql',]
  }],
  // page4部分
  page4: {
    // 我的历程
    course: [{
      date: '2019/9——2021/9', // 时间
      desc: { // 经历
        title: '立志报国，参军入伍',
        list: ['服役期间表现出色，因参加多次考核中突出表现入选炊事班	', '2021年满服役期限，因表现良好授予“四有优秀士兵”。', '']
      }
    }, {
      date: '2021/9——2022/2',
      desc: {
        title: '退役复学，就读广东东软学院',
        list: ['开始学习Python语言', '构建简单的代码逻辑执行，可以开发单机类的小游戏，如坦克大战，魂斗罗等小游戏', '维护代码，进行更新迭代','初次开发出个人的淘宝京东抢单助手软件','学习MySQL初等操作','简单是用Python语言结合MySQL进行实时数据交互']
      }
    }, {
      date: '2022/2——至今',
      desc: {
        title: '偷偷学习技术，努力深耕，并卷死他们。',
        list: ['开发对彩票网站实时获取开奖号码的脚本', '进一步学习使用MySQL数据库进行对接，实现数据实时交互', '学习Web网页编程', '使用CSS进行模拟京东购物车静态页面', 'Web编程技术实现进阶，使用JavaScript，UI，Vue框架等技术单独开发了多个动态网页']
      }
    }],
    // 我的拓展技能掌握
    singlelist: [{
      title: 'bootsrap',
      text: '了解'
    }, {
      title: 'Element-ui',
      text: '掌握'
    }, {
      title: 'mint-ui',
      text: '掌握'
    }, {
      title: 'scss',
      text: '掌握'
    }],
    // 我的基本技能掌握
    proresslist: [{
      title: 'HTML、CSS、SCSS',
      value: '90%'
    }, {
      title: 'JS、JQ',
      value: '81%'
    }, {
      title: 'Vue',
      value: '85%'
    }, {
      title: 'NodeJs',
      value: '76%'
    }, {
      title: 'SQL',
      value: '69%'
    }]
  },
  // page5部分
  page5: [{
    title: '新兵连留念合照',
    content: '在浙江湖州特战二支队新兵连留影拍照',
    image: 'box1.png',
    href: 'src/img/box1.png'
  }, {
    title: '2年服役期满，退伍合照',
    content: '退役时的留影合照，我知道这是最后一次属于我的军旅回忆....”',
    image: 'box3.jpg',
    href: 'src/img/box3.jpg'
  }, {
    title: '这个是熟悉的400米障碍场',
    content: '当兵第二年时，曾经是战友们乐此不疲的“苦”',
    image: 'box5.jpg',
    href: 'src/img/box5.png'
  }, {
    title: '深圳南山区深圳湾体育场',
    content: '仅仅在新兵连待了3个多月后，下连时去的第一个任务地区',
    image: 'box2.png',
    href: 'src/img/box2.png'
  }, {
    title: '退伍纪念',
    content: '为军旅生涯画上圆满句号',
    image: 'box4.png',
    href: 'src/img/box4.png'
  }, {
    title: '初中回忆',
    content: '别问为什么不放高中的，因为...',
    image: 'box6.png',
    href: 'src/img/box6.png'
  }],
  // page6部分
  page6: {
    github: 'https://github.com/wttAndroid',
    bili: '',
    email: 'Mailto:2260676654@qq.com?Subject=邮箱标题&Body=邮箱内容！',
    zhihu: '',
    weixin: "<img style='width:120px' src='src/img/wtf1.jpg' alt='加载失败'>",
    qq: "<img style='width:120px' src='src/img/wtf2.jpg' alt='加载失败'>"
  }
}
